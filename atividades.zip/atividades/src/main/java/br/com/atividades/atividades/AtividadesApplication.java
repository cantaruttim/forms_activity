package br.com.atividades.atividades;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtividadesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtividadesApplication.class, args);
	}

}
